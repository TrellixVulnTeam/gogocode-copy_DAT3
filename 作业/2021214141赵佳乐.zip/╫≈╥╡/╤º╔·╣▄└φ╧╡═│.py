from tkinter import *
import csv
################################################################################
##############################################################################
#####此代码有bug，第58和60行的代码定义了却无法识别，未解决问题，所以该软件无法进行修改信息和添加信息
#####后来打算换成将信息储存在文件中的形式，但时间问题导致没学完，最终也未能成功做出 呜呜呜~~~
#################################################################################
##################################################################################

# 寻找学生
def search():
    data = entry.get().strip()
    judge = '0'
    for i in name_list:
        if data == i:
            num = name_list.index(i)
            var.set("姓名：" + name_list[num] + "\n学号：" + number_list[num] + "\n数学成绩：" + math_grade_list[num] + "\n英语成绩：" +
                    english_grade_list[num])
            judge = '1'
            break
    for j in number_list:
        if data == j:
            num = number_list.index(j)
            var.set("姓名：" + name_list[num] + "\n学号：" + number_list[num] + "\n数学成绩：" + math_grade_list[num] + "\n英语成绩：" +
                    english_grade_list[num])
            judge = '1'
            break
    if judge == '0':
        var.set("查无此人")


# 添加学生
def add():
    new_window()


# 删除学生
def delete():
    data = entry.get().strip()
    judge = '0'
    for i in name_list:
        if data == i:
            num = name_list.index(i)
            del name_list[num], number_list[num], math_grade_list[num], english_grade_list[num]
            judge = '1'
    for j in number_list:
        if data == j:
            num = name_list.index(j)
            del name_list[num], number_list[num], math_grade_list[num], english_grade_list[num]
            judge = '1'
    if judge == '1':
        var.set("清除成功")
    else:
        var.set("查无此人，清除失败！")


# 更改学生信息
def change():
    new_window()
    data = entry_new.get().strip()
    if data == "666":
        var_new.set("233")


def new_window():
    var_new = StringVar()
    window_new = Toplevel()
    window_new.geometry('540x540+800+150')
    window_new.resizable(False, False)
    window_new.title("学生信息修改/添加")
    Label(window_new, text="请按照以下格式填写信息", font=("宋体", 14)).pack()
    Label(window_new, text="姓名 学号 数学成绩 英语成绩", font=("宋体", 14)).pack()
    entry_new = Entry(window_new, width=50)
    entry_new.pack()
    button_new = Button(window_new, text="确定", width=15, height=2, command=search)
    button_new.pack()
    label_new = Label(window, textvariable=var_new, font=("宋体", 10), width=150, height=14)
    label_new.pack()


# 主界面框架设置
window = Tk()
window.geometry('540x540+800+150')
window.resizable(False, False)
window.title("学生管理系统(该界面在2k分辨率测试，显示正常)")
var = StringVar()
# 放置操作提示
Label(window, text="请输入要查询的学生名称或者学号：", font=("宋体", 14)).pack()

# 输入框放置
entry = Entry(window)
entry.pack()

# 显示栏放置
label = Label(window, textvariable=var, font=("宋体", 10), width=150, height=14)
label.pack()

# 按钮放置
button = Button(window, text="搜索学生信息", width=15, height=2, command=search)
button.pack()
button = Button(window, text="添加学生信息", width=15, height=2, command=add)
button.pack()
button = Button(window, text="删除学生信息", width=15, height=2, command=delete)
button.pack()
button = Button(window, text="修改学生信息", width=15, height=2, command=change)
button.pack()

name_list = ["张三", "李四"]
number_list = ["333", "4444"]
math_grade_list = ["78", "44"]
english_grade_list = ["60", "88"]

window.mainloop()

for gongji in range(1,21):
    for muji in range(1,34):
        for xiaoji in range(1,301):
            if (gongji*5+muji*3+xiaoji/3 <= 100):
                print("公鸡",gongji ,"母鸡",muji ,"小鸡",xiaoji )
def shuixianhua_judge(i):
    a = i//100       #求百位
    b = (i//10)%10   #求十位
    c = i%10         #求个位
    if i == a**3 + b**3 + c**3:
        return True
    else:
        return False

for i in range(100,1000):
    if shuixianhua_judge(i):
        print(i)